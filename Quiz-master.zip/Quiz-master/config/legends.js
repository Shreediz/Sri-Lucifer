module.exports = {
  SITE_EMAIL: "biticonic@usermanagement.com",
  SITE_NAME: "Bit Iconic",
  SITE_URL: " http://localhost:3000/"
};
