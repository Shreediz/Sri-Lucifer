module.exports={
    MORNING:1,
    DAY:2,
    EVENING:3
}