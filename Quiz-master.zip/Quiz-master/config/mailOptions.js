module.exports= {
    from: "thisisjustdummysaurav@gmail.com", // sender address
    to: "sauravads123@gmail.com,manandhar.praful13@gmail.com", // list of receivers
    subject: "Please confirm your Email account", // Subject line
    html: "<p>If you are seeing this then there is error!</p>" // plain text body
  };