module.exports={
    MAX_LOGIN_ATTEMPT:5
}