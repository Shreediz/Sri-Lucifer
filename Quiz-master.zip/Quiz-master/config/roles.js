module.exports = {
  USER: 1,
  ADMIN: 2,
  SUPERADMIN: 3,
  CUSTOMER: 4,
  SUPPLIER: 5
};
