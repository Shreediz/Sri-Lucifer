module.exports = {
  secretOrKey: process.env.JWT_SECRET
};
