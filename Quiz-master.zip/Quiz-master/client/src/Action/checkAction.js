export const checkin=()=>({
  type:'CHECKIN'
})
export const checkout=()=>({
  type:'CHECKOUT'
})
