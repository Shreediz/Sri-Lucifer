export default {
  DRAFT: "badge p-1 badge-secondary text-white te",
  CONFIRMED: "badge p-1  badge-primary text-white",
  DELIVERED: "badge p-1 badge-info text-white",
  CANCELLED: "badge p-1 badge-danger text-white",
  FULFILLED: "badge p-1 badge-success text-white"
};
