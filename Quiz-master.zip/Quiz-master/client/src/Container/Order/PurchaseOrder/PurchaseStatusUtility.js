export default {
  DRAFT: "badge p-1 badge-secondary text-white te",
  ISSUED: "badge p-1  badge-primary text-white",
  RECEIVED: "badge p-1 badge-info text-white",
  CANCELLED: "badge p-1 badge-danger text-white",
  FULFILLED: "badge p-1 badge-success text-white"
};
